# Simulador Interactivo de Finanzas Personales

## Descripción del Proyecto

Una aplicación web moderna y visualmente atractiva que permite a los usuarios gestionar sus ingresos y gastos de forma interactiva, motivadora y gamificada. El sistema utiliza visualización de datos en tiempo real, efectos de sonido y un sistema de logros para fomentar buenos hábitos financieros.

## Características Principales

### 💰 Gestión de Transacciones
- Formulario intuitivo para registrar ingresos y egresos
- Categorías predefinidas con emojis visuales
- Validación en tiempo real con Zod
- Campos opcionales para descripción y fecha personalizada

### 📊 Visualización de Datos
- **Gráfico de Líneas**: Evolución del balance en el tiempo (Chart.js)
- **Gráfico de Dona**: Distribución de gastos por categoría
- Tarjetas de resumen con estadísticas en tiempo real
- Animaciones suaves en todas las actualizaciones

### 🎮 Gamificación
- Sistema de logros desbloqueables:
  - 🌟 Primer Paso (primera transacción)
  - 💎 Ahorrista Nivel 1 (7 días positivo)
  - 🏆 Guardián del Ahorro (30 días positivo)
  - 👑 Maestro Financiero (balance > $10,000)
  - 📊 Organizador (50 transacciones)
- Barra de progreso visual
- Celebraciones con confetti al desbloquear logros

### 🎨 Diseño Visual
- Tema claro/oscuro con toggle
- Colores diferenciados para ingresos (verde) y egresos (rojo)
- Mensajes motivacionales dinámicos según el estado financiero
- Animaciones CSS personalizadas (fade-in, pulse, shake, slide)
- Diseño completamente responsivo (móvil, tablet, desktop)

### 🔊 Efectos de Sonido
- Sonido de éxito al registrar transacciones
- Fanfarria al desbloquear logros
- Control de volumen y opción de silenciar
- Implementado con Web Audio API

### 💾 Persistencia de Datos
- **LocalStorage** para almacenamiento local del navegador
- Sin necesidad de servidor para funcionar
- Datos persistentes entre sesiones
- Backend opcional disponible para futuras extensiones

## Tecnologías Utilizadas

### Frontend
- **React** - Framework de UI
- **TypeScript** - Tipado estático
- **Tailwind CSS** - Estilos y diseño responsivo
- **shadcn/ui** - Componentes de UI
- **Wouter** - Enrutamiento
- **TanStack Query** - Gestión de estado y caché
- **React Hook Form** - Gestión de formularios
- **Zod** - Validación de esquemas
- **Chart.js 4.5.1** - Gráficas animadas
- **Howler.js 2.2.4** - Audio (opcional)
- **Canvas Confetti** - Efectos de celebración

### Backend (Opcional)
- **Express.js** - Servidor HTTP
- **Drizzle ORM** - ORM para base de datos
- **In-Memory Storage** - Almacenamiento temporal

### Tipografías
- **Poppins** - Interfaz general (400, 600, 700)
- **JetBrains Mono** - Números y montos (400, 600)

## Arquitectura

### Estructura de Carpetas
```
client/
├── src/
│   ├── components/          # Componentes React reutilizables
│   │   ├── Header.tsx
│   │   ├── BalanceCard.tsx
│   │   ├── IncomeExpenseCards.tsx
│   │   ├── TransactionForm.tsx
│   │   ├── BalanceChart.tsx
│   │   ├── CategoryChart.tsx
│   │   ├── AchievementBadges.tsx
│   │   ├── TransactionsList.tsx
│   │   ├── SettingsModal.tsx
│   │   └── ThemeProvider.tsx
│   ├── pages/               # Páginas de la aplicación
│   │   └── Dashboard.tsx
│   ├── hooks/               # Hooks personalizados
│   │   ├── useLocalStorage.ts
│   │   └── useTheme.ts
│   ├── lib/                 # Utilidades y datos
│   │   ├── categoriasData.ts
│   │   ├── logrosData.ts
│   │   └── mensajesMotivacionales.ts
│   └── index.css            # Estilos globales y animaciones
├── shared/
│   └── schema.ts            # Esquemas TypeScript compartidos
└── server/
    ├── routes.ts            # Rutas API
    └── storage.ts           # Capa de almacenamiento
```

### Esquema de Datos

#### Transacción
```typescript
{
  id: string
  tipo: 'ingreso' | 'egreso'
  categoria: string
  monto: decimal
  descripcion?: string
  fecha: Date
}
```

#### Categoría
```typescript
{
  id: string
  nombre: string
  emoji: string
  tipo: 'ingreso' | 'egreso'
  personalizada: 0 | 1
}
```

#### Configuración
```typescript
{
  id: string
  tema: 'light' | 'dark'
  sonidosHabilitados: 0 | 1
  volumen: number (0-100)
}
```

#### Logro
```typescript
{
  id: string
  codigo: string
  desbloqueado: 0 | 1
  fechaDesbloqueo?: Date
}
```

## Categorías Predefinidas

### Ingresos
- 💰 Salario
- 💼 Freelance
- 📈 Inversiones
- 🎁 Regalo
- 🏷️ Venta
- 💵 Otros Ingresos

### Egresos
- 🍕 Comida
- 🏠 Vivienda
- 🚗 Transporte
- 🎉 Entretenimiento
- 🏥 Salud
- 📚 Educación
- 🛍️ Compras
- 💳 Servicios
- 💸 Otros Gastos

## Estados Financieros y Mensajes

### 🟢 Saludable (Balance Positivo)
- "💪 ¡Excelente! Sigues en positivo, sigue así"
- "😊 ¡Vas muy bien! Tu balance es saludable"
- Emoji: 😊

### 🟡 Precaución (Gastos > 70% Ingresos)
- "⚠️ Atención: tus gastos están alcanzando el 70% de tus ingresos"
- "⚠️ Cuidado, tus gastos están aumentando esta semana"
- Emoji: 😐

### 🔴 Riesgo (Balance Negativo)
- "🚨 Alerta: estás gastando más de lo que ingresas este mes"
- "🚨 ¡Atención! Tu balance es negativo"
- Emoji: 😟

## Uso de la Aplicación

### Registrar una Transacción
1. Selecciona el tipo (Ingreso o Egreso)
2. Elige una categoría del menú desplegable
3. Ingresa el monto
4. Opcionalmente agrega descripción y fecha
5. Haz clic en "Agregar Transacción"

### Cambiar el Tema
- Haz clic en el ícono de Luna/Sol en la cabecera
- El tema se guarda automáticamente

### Configurar Sonidos
1. Haz clic en el ícono de configuración (⚙️)
2. Ve a la pestaña "Sonido"
3. Activa/desactiva los efectos de sonido
4. Ajusta el volumen con el deslizador

### Desbloquear Logros
Los logros se desbloquean automáticamente al cumplir ciertos criterios:
- Registrar transacciones
- Mantener balance positivo
- Alcanzar metas financieras

## Características Técnicas

### Rendimiento
- Componentes React optimizados con hooks
- Gráficas renderizadas con Canvas (Chart.js)
- Almacenamiento local asíncrono
- Animaciones aceleradas por GPU

### Accesibilidad
- Contraste WCAG AA compliant
- Labels descriptivos en formularios
- Estados de foco visibles
- Textos alternativos en elementos visuales
- Atributos data-testid para testing

### Responsividad
- **Mobile**: Layout vertical apilado
- **Tablet (768px+)**: Layout de 2 columnas
- **Desktop (1024px+)**: Layout asimétrico 33%/67%

## Futuras Mejoras Posibles

- Exportación de datos a CSV/PDF
- Metas de ahorro personalizadas
- Recordatorios de gastos recurrentes
- Comparativas de múltiples períodos
- Calculadora de proyecciones financieras
- Sincronización con base de datos (backend ya implementado)
- Autenticación de usuarios
- Compartir estadísticas

## Desarrollo

### Iniciar el Proyecto
```bash
npm run dev
```

### Estructura de Comandos
- `npm run dev` - Inicia servidor de desarrollo
- `npm run build` - Construye para producción
- `npm run preview` - Preview de producción

## Notas de Implementación

- La aplicación funciona completamente offline usando LocalStorage
- El backend está implementado pero es opcional
- Todos los cálculos se realizan en el frontend
- Las gráficas se actualizan en tiempo real
- Los datos persisten entre sesiones del navegador
