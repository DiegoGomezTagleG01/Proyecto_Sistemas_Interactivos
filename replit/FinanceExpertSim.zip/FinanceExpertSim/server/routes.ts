import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTransaccionSchema, insertCategoriaSchema, insertConfiguracionSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // ============================================
  // RUTAS DE TRANSACCIONES
  // ============================================

  // Obtener todas las transacciones
  app.get("/api/transacciones", async (req, res) => {
    try {
      const transacciones = await storage.getTransacciones();
      res.json(transacciones);
    } catch (error) {
      res.status(500).json({ error: "Error al obtener transacciones" });
    }
  });

  // Obtener una transacción por ID
  app.get("/api/transacciones/:id", async (req, res) => {
    try {
      const transaccion = await storage.getTransaccion(req.params.id);
      if (!transaccion) {
        return res.status(404).json({ error: "Transacción no encontrada" });
      }
      res.json(transaccion);
    } catch (error) {
      res.status(500).json({ error: "Error al obtener transacción" });
    }
  });

  // Crear una nueva transacción
  app.post("/api/transacciones", async (req, res) => {
    try {
      const validatedData = insertTransaccionSchema.parse(req.body);
      const transaccion = await storage.createTransaccion(validatedData);
      res.status(201).json(transaccion);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Datos inválidos", details: error.errors });
      }
      res.status(500).json({ error: "Error al crear transacción" });
    }
  });

  // Eliminar una transacción
  app.delete("/api/transacciones/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteTransaccion(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Transacción no encontrada" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Error al eliminar transacción" });
    }
  });

  // Eliminar todas las transacciones
  app.delete("/api/transacciones", async (req, res) => {
    try {
      await storage.deleteAllTransacciones();
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Error al eliminar transacciones" });
    }
  });

  // ============================================
  // RUTAS DE CATEGORÍAS
  // ============================================

  // Obtener todas las categorías
  app.get("/api/categorias", async (req, res) => {
    try {
      const tipo = req.query.tipo as 'ingreso' | 'egreso' | undefined;
      
      if (tipo && (tipo === 'ingreso' || tipo === 'egreso')) {
        const categorias = await storage.getCategoriasPorTipo(tipo);
        return res.json(categorias);
      }
      
      const categorias = await storage.getCategorias();
      res.json(categorias);
    } catch (error) {
      res.status(500).json({ error: "Error al obtener categorías" });
    }
  });

  // Crear una nueva categoría personalizada
  app.post("/api/categorias", async (req, res) => {
    try {
      const validatedData = insertCategoriaSchema.parse(req.body);
      const categoria = await storage.createCategoria(validatedData);
      res.status(201).json(categoria);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Datos inválidos", details: error.errors });
      }
      res.status(500).json({ error: "Error al crear categoría" });
    }
  });

  // ============================================
  // RUTAS DE CONFIGURACIÓN
  // ============================================

  // Obtener configuración
  app.get("/api/configuracion", async (req, res) => {
    try {
      const config = await storage.getConfiguracion();
      res.json(config);
    } catch (error) {
      res.status(500).json({ error: "Error al obtener configuración" });
    }
  });

  // Actualizar configuración
  app.patch("/api/configuracion", async (req, res) => {
    try {
      const validatedData = insertConfiguracionSchema.partial().parse(req.body);
      const config = await storage.updateConfiguracion(validatedData);
      res.json(config);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Datos inválidos", details: error.errors });
      }
      res.status(500).json({ error: "Error al actualizar configuración" });
    }
  });

  // ============================================
  // RUTAS DE LOGROS
  // ============================================

  // Obtener todos los logros
  app.get("/api/logros", async (req, res) => {
    try {
      const logros = await storage.getLogros();
      res.json(logros);
    } catch (error) {
      res.status(500).json({ error: "Error al obtener logros" });
    }
  });

  // Actualizar estado de un logro
  app.patch("/api/logros/:codigo", async (req, res) => {
    try {
      const { desbloqueado } = req.body;
      if (typeof desbloqueado !== 'boolean') {
        return res.status(400).json({ error: "El campo 'desbloqueado' debe ser booleano" });
      }
      
      const logro = await storage.updateLogro(req.params.codigo, desbloqueado);
      if (!logro) {
        return res.status(404).json({ error: "Logro no encontrado" });
      }
      
      res.json(logro);
    } catch (error) {
      res.status(500).json({ error: "Error al actualizar logro" });
    }
  });

  // ============================================
  // RUTA DE ESTADÍSTICAS (Calculadas)
  // ============================================

  app.get("/api/estadisticas", async (req, res) => {
    try {
      const transacciones = await storage.getTransacciones();
      
      // Calcular totales
      const totalIngresos = transacciones
        .filter(t => t.tipo === 'ingreso')
        .reduce((sum, t) => sum + parseFloat(t.monto.toString()), 0);

      const totalEgresos = transacciones
        .filter(t => t.tipo === 'egreso')
        .reduce((sum, t) => sum + parseFloat(t.monto.toString()), 0);

      const balance = totalIngresos - totalEgresos;

      // Agrupar por día
      const transaccionesPorDia: { fecha: string; balance: number }[] = [];
      const diasUnicos = new Set(
        transacciones.map(t => new Date(t.fecha).toISOString().split('T')[0])
      );

      const fechasOrdenadas = Array.from(diasUnicos).sort();
      let balanceAcumulado = 0;

      fechasOrdenadas.forEach(fecha => {
        const transaccionesDia = transacciones.filter(
          t => new Date(t.fecha).toISOString().split('T')[0] === fecha
        );

        const balanceDia = transaccionesDia.reduce((sum, t) => {
          const monto = parseFloat(t.monto.toString());
          return sum + (t.tipo === 'ingreso' ? monto : -monto);
        }, 0);

        balanceAcumulado += balanceDia;
        transaccionesPorDia.push({ fecha, balance: balanceAcumulado });
      });

      // Agrupar gastos por categoría
      const gastosPorCategoriaMap = new Map<string, { monto: number; emoji: string }>();
      
      transacciones
        .filter(t => t.tipo === 'egreso')
        .forEach(t => {
          const monto = parseFloat(t.monto.toString());
          const actual = gastosPorCategoriaMap.get(t.categoria) || { monto: 0, emoji: '' };
          gastosPorCategoriaMap.set(t.categoria, {
            monto: actual.monto + monto,
            emoji: actual.emoji
          });
        });

      const gastosPorCategoria = Array.from(gastosPorCategoriaMap.entries()).map(
        ([categoria, data]) => ({
          categoria,
          monto: data.monto,
          emoji: data.emoji
        })
      );

      res.json({
        totalIngresos,
        totalEgresos,
        balance,
        transaccionesPorDia,
        gastosPorCategoria,
      });
    } catch (error) {
      res.status(500).json({ error: "Error al calcular estadísticas" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
