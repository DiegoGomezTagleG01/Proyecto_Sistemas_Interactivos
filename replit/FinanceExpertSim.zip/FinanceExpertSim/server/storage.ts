import { 
  type Transaccion, 
  type InsertTransaccion,
  type Categoria,
  type InsertCategoria,
  type Configuracion,
  type InsertConfiguracion,
  type Logro,
  type InsertLogro
} from "@shared/schema";
import { randomUUID } from "crypto";

// Interfaz de almacenamiento para el simulador de finanzas
export interface IStorage {
  // Transacciones
  getTransacciones(): Promise<Transaccion[]>;
  getTransaccion(id: string): Promise<Transaccion | undefined>;
  createTransaccion(transaccion: InsertTransaccion): Promise<Transaccion>;
  deleteTransaccion(id: string): Promise<boolean>;
  deleteAllTransacciones(): Promise<void>;

  // Categorías
  getCategorias(): Promise<Categoria[]>;
  getCategoriasPorTipo(tipo: 'ingreso' | 'egreso'): Promise<Categoria[]>;
  createCategoria(categoria: InsertCategoria): Promise<Categoria>;

  // Configuración
  getConfiguracion(): Promise<Configuracion>;
  updateConfiguracion(config: Partial<InsertConfiguracion>): Promise<Configuracion>;

  // Logros
  getLogros(): Promise<Logro[]>;
  updateLogro(codigo: string, desbloqueado: boolean): Promise<Logro | undefined>;
}

export class MemStorage implements IStorage {
  private transacciones: Map<string, Transaccion>;
  private categorias: Map<string, Categoria>;
  private configuracion: Configuracion;
  private logros: Map<string, Logro>;

  constructor() {
    this.transacciones = new Map();
    this.categorias = new Map();
    this.logros = new Map();

    // Inicializar configuración por defecto
    this.configuracion = {
      id: randomUUID(),
      tema: 'light',
      sonidosHabilitados: 1,
      volumen: 50,
    };

    // Inicializar categorías predefinidas
    this.inicializarCategoriasPredefinidas();
    
    // Inicializar logros
    this.inicializarLogros();
  }

  private inicializarCategoriasPredefinidas() {
    const categoriasInicio: InsertCategoria[] = [
      // Ingresos
      { nombre: "Salario", emoji: "💰", tipo: "ingreso", personalizada: 0 },
      { nombre: "Freelance", emoji: "💼", tipo: "ingreso", personalizada: 0 },
      { nombre: "Inversiones", emoji: "📈", tipo: "ingreso", personalizada: 0 },
      { nombre: "Regalo", emoji: "🎁", tipo: "ingreso", personalizada: 0 },
      { nombre: "Venta", emoji: "🏷️", tipo: "ingreso", personalizada: 0 },
      { nombre: "Otros Ingresos", emoji: "💵", tipo: "ingreso", personalizada: 0 },
      
      // Egresos
      { nombre: "Comida", emoji: "🍕", tipo: "egreso", personalizada: 0 },
      { nombre: "Vivienda", emoji: "🏠", tipo: "egreso", personalizada: 0 },
      { nombre: "Transporte", emoji: "🚗", tipo: "egreso", personalizada: 0 },
      { nombre: "Entretenimiento", emoji: "🎉", tipo: "egreso", personalizada: 0 },
      { nombre: "Salud", emoji: "🏥", tipo: "egreso", personalizada: 0 },
      { nombre: "Educación", emoji: "📚", tipo: "egreso", personalizada: 0 },
      { nombre: "Compras", emoji: "🛍️", tipo: "egreso", personalizada: 0 },
      { nombre: "Servicios", emoji: "💳", tipo: "egreso", personalizada: 0 },
      { nombre: "Otros Gastos", emoji: "💸", tipo: "egreso", personalizada: 0 },
    ];

    categoriasInicio.forEach(cat => {
      const id = randomUUID();
      this.categorias.set(id, { ...cat, id });
    });
  }

  private inicializarLogros() {
    const logrosInicio = [
      "primer_paso",
      "ahorrista_7dias",
      "guardian_30dias",
      "maestro_financiero",
      "organizador",
    ];

    logrosInicio.forEach(codigo => {
      const id = randomUUID();
      this.logros.set(id, {
        id,
        codigo,
        desbloqueado: 0,
        fechaDesbloqueo: null,
      });
    });
  }

  // Implementación de métodos de transacciones
  async getTransacciones(): Promise<Transaccion[]> {
    return Array.from(this.transacciones.values());
  }

  async getTransaccion(id: string): Promise<Transaccion | undefined> {
    return this.transacciones.get(id);
  }

  async createTransaccion(insertTransaccion: InsertTransaccion): Promise<Transaccion> {
    const id = randomUUID();
    const transaccion: Transaccion = {
      ...insertTransaccion,
      id,
      fecha: new Date(),
    };
    this.transacciones.set(id, transaccion);
    return transaccion;
  }

  async deleteTransaccion(id: string): Promise<boolean> {
    return this.transacciones.delete(id);
  }

  async deleteAllTransacciones(): Promise<void> {
    this.transacciones.clear();
  }

  // Implementación de métodos de categorías
  async getCategorias(): Promise<Categoria[]> {
    return Array.from(this.categorias.values());
  }

  async getCategoriasPorTipo(tipo: 'ingreso' | 'egreso'): Promise<Categoria[]> {
    return Array.from(this.categorias.values()).filter(c => c.tipo === tipo);
  }

  async createCategoria(insertCategoria: InsertCategoria): Promise<Categoria> {
    const id = randomUUID();
    const categoria: Categoria = {
      ...insertCategoria,
      id,
    };
    this.categorias.set(id, categoria);
    return categoria;
  }

  // Implementación de métodos de configuración
  async getConfiguracion(): Promise<Configuracion> {
    return this.configuracion;
  }

  async updateConfiguracion(config: Partial<InsertConfiguracion>): Promise<Configuracion> {
    this.configuracion = {
      ...this.configuracion,
      ...config,
    };
    return this.configuracion;
  }

  // Implementación de métodos de logros
  async getLogros(): Promise<Logro[]> {
    return Array.from(this.logros.values());
  }

  async updateLogro(codigo: string, desbloqueado: boolean): Promise<Logro | undefined> {
    const logro = Array.from(this.logros.values()).find(l => l.codigo === codigo);
    if (logro) {
      logro.desbloqueado = desbloqueado ? 1 : 0;
      logro.fechaDesbloqueo = desbloqueado ? new Date() : null;
      this.logros.set(logro.id, logro);
      return logro;
    }
    return undefined;
  }
}

export const storage = new MemStorage();
