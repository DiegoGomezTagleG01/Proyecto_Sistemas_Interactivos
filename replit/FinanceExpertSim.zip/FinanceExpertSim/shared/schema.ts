import { sql } from "drizzle-orm";
import { pgTable, text, varchar, decimal, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// ============================================
// ESQUEMA DE TRANSACCIONES FINANCIERAS
// ============================================

export const transacciones = pgTable("transacciones", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tipo: text("tipo").notNull(), // 'ingreso' o 'egreso'
  categoria: text("categoria").notNull(),
  monto: decimal("monto", { precision: 12, scale: 2 }).notNull(),
  descripcion: text("descripcion"),
  fecha: timestamp("fecha").notNull().defaultNow(),
});

export const insertTransaccionSchema = createInsertSchema(transacciones).omit({
  id: true,
  fecha: true,
}).extend({
  tipo: z.enum(['ingreso', 'egreso'], {
    required_error: "Debes seleccionar el tipo de transacción"
  }),
  categoria: z.string().min(1, "Debes seleccionar una categoría"),
  monto: z.string().min(1, "El monto es requerido").refine(
    (val) => !isNaN(parseFloat(val)) && parseFloat(val) > 0,
    "El monto debe ser un número positivo"
  ),
  descripcion: z.string().optional(),
  fecha: z.string().optional(),
});

export type InsertTransaccion = z.infer<typeof insertTransaccionSchema>;
export type Transaccion = typeof transacciones.$inferSelect;

// ============================================
// ESQUEMA DE CATEGORÍAS PERSONALIZADAS
// ============================================

export const categorias = pgTable("categorias", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  nombre: text("nombre").notNull(),
  emoji: text("emoji").notNull(),
  tipo: text("tipo").notNull(), // 'ingreso' o 'egreso'
  personalizada: integer("personalizada").notNull().default(0), // 0 = predefinida, 1 = personalizada
});

export const insertCategoriaSchema = createInsertSchema(categorias).omit({
  id: true,
});

export type InsertCategoria = z.infer<typeof insertCategoriaSchema>;
export type Categoria = typeof categorias.$inferSelect;

// ============================================
// ESQUEMA DE CONFIGURACIÓN DEL USUARIO
// ============================================

export const configuracion = pgTable("configuracion", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tema: text("tema").notNull().default('light'), // 'light' o 'dark'
  sonidosHabilitados: integer("sonidos_habilitados").notNull().default(1),
  volumen: integer("volumen").notNull().default(50),
});

export const insertConfiguracionSchema = createInsertSchema(configuracion).omit({
  id: true,
});

export type InsertConfiguracion = z.infer<typeof insertConfiguracionSchema>;
export type Configuracion = typeof configuracion.$inferSelect;

// ============================================
// ESQUEMA DE LOGROS/ACHIEVEMENTS
// ============================================

export const logros = pgTable("logros", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  codigo: text("codigo").notNull().unique(), // 'ahorrista_7dias', 'guardian_30dias', etc
  desbloqueado: integer("desbloqueado").notNull().default(0),
  fechaDesbloqueo: timestamp("fecha_desbloqueo"),
});

export const insertLogroSchema = createInsertSchema(logros).omit({
  id: true,
  fechaDesbloqueo: true,
});

export type InsertLogro = z.infer<typeof insertLogroSchema>;
export type Logro = typeof logros.$inferSelect;

// ============================================
// INTERFACES Y TIPOS PARA FRONTEND
// ============================================

// Categorías predefinidas del sistema
export interface CategoriaDefinida {
  nombre: string;
  emoji: string;
  tipo: 'ingreso' | 'egreso';
}

// Estadísticas financieras calculadas
export interface EstadisticasFinancieras {
  totalIngresos: number;
  totalEgresos: number;
  balance: number;
  transaccionesPorDia: { fecha: string; balance: number }[];
  gastosPorCategoria: { categoria: string; monto: number; emoji: string }[];
}

// Definición de logros disponibles
export interface DefinicionLogro {
  codigo: string;
  titulo: string;
  descripcion: string;
  emoji: string;
  criterio: (stats: EstadisticasFinancieras, transacciones: Transaccion[]) => boolean;
}

// Estado financiero para alertas
export type EstadoFinanciero = 'saludable' | 'precaucion' | 'riesgo';

export interface MensajeMotivacional {
  tipo: EstadoFinanciero;
  mensaje: string;
  emoji: string;
}
