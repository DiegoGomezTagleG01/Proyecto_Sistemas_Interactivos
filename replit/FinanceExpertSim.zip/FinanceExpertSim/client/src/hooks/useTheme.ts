import { useEffect } from 'react';
import { useLocalStorage } from './useLocalStorage';

type Theme = 'light' | 'dark';

/**
 * Hook para gestionar el tema oscuro/claro de la aplicación
 * Sincroniza con localStorage y actualiza la clase en el documento
 */
export function useTheme() {
  const [theme, setTheme] = useLocalStorage<Theme>('finanzas-theme', 'light');

  useEffect(() => {
    // Actualizar clase en el elemento raíz del documento
    const root = window.document.documentElement;
    
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prevTheme => prevTheme === 'light' ? 'dark' : 'light');
  };

  return { theme, setTheme, toggleTheme };
}
