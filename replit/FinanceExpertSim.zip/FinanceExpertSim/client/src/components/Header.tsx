import { Settings, Moon, Sun } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useThemeContext } from './ThemeProvider';

interface HeaderProps {
  onOpenSettings: () => void;
}

/**
 * Cabecera principal de la aplicación
 * Muestra título, toggle de tema y botón de configuración
 */
export function Header({ onOpenSettings }: HeaderProps) {
  const { theme, toggleTheme } = useThemeContext();

  return (
    <header className="w-full border-b bg-card border-card-border">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Título de la aplicación */}
          <div className="flex items-center gap-3">
            <div className="text-3xl sm:text-4xl">💰</div>
            <div>
              <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-foreground">
                Mis Finanzas
              </h1>
              <p className="text-xs sm:text-sm text-muted-foreground hidden sm:block">
                Gestiona tu dinero de forma inteligente
              </p>
            </div>
          </div>

          {/* Controles de la cabecera */}
          <div className="flex items-center gap-2">
            {/* Toggle de tema oscuro/claro */}
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              data-testid="button-toggle-theme"
              className="hover-elevate active-elevate-2"
              aria-label={theme === 'dark' ? 'Cambiar a modo claro' : 'Cambiar a modo oscuro'}
            >
              {theme === 'dark' ? (
                <Sun className="h-5 w-5" />
              ) : (
                <Moon className="h-5 w-5" />
              )}
            </Button>

            {/* Botón de configuración */}
            <Button
              variant="ghost"
              size="icon"
              onClick={onOpenSettings}
              data-testid="button-open-settings"
              className="hover-elevate active-elevate-2"
              aria-label="Abrir configuración"
            >
              <Settings className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
