import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface IncomeExpenseCardsProps {
  totalIngresos: number;
  totalEgresos: number;
}

/**
 * Tarjetas gemelas que muestran ingresos y egresos totales
 * Diseñadas con colores diferenciados verde/rojo
 */
export function IncomeExpenseCards({ totalIngresos, totalEgresos }: IncomeExpenseCardsProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
      {/* Tarjeta de Ingresos */}
      <Card 
        className="border-ingreso/30 bg-ingreso/5 animate-fade-in-up"
        data-testid="card-ingresos"
        style={{ animationDelay: '100ms' }}
      >
        <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
          <CardTitle className="text-sm sm:text-base font-semibold text-foreground">
            Ingresos Totales
          </CardTitle>
          <div className="p-2 rounded-md bg-ingreso/10">
            <TrendingUp className="h-4 w-4 sm:h-5 sm:w-5 text-ingreso" />
          </div>
        </CardHeader>
        <CardContent>
          <div 
            className="font-mono text-2xl sm:text-3xl font-bold text-ingreso"
            data-testid="text-total-ingresos"
          >
            ${totalIngresos.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Dinero que has recibido
          </p>
        </CardContent>
      </Card>

      {/* Tarjeta de Egresos */}
      <Card 
        className="border-egreso/30 bg-egreso/5 animate-fade-in-up"
        data-testid="card-egresos"
        style={{ animationDelay: '200ms' }}
      >
        <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
          <CardTitle className="text-sm sm:text-base font-semibold text-foreground">
            Egresos Totales
          </CardTitle>
          <div className="p-2 rounded-md bg-egreso/10">
            <TrendingDown className="h-4 w-4 sm:h-5 sm:w-5 text-egreso" />
          </div>
        </CardHeader>
        <CardContent>
          <div 
            className="font-mono text-2xl sm:text-3xl font-bold text-egreso"
            data-testid="text-total-egresos"
          >
            ${totalEgresos.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Dinero que has gastado
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
