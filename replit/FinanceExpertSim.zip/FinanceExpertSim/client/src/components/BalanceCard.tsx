import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { getEmojiEstado, determinarEstadoFinanciero, getMensajeMotivacional } from '@/lib/mensajesMotivacionales';
import type { EstadoFinanciero } from '@shared/schema';
import { useEffect, useState } from 'react';

interface BalanceCardProps {
  balance: number;
  totalIngresos: number;
  totalEgresos: number;
}

/**
 * Tarjeta principal que muestra el balance total
 * Incluye emoji de estado y mensaje motivacional
 */
export function BalanceCard({ balance, totalIngresos, totalEgresos }: BalanceCardProps) {
  const [previousBalance, setPreviousBalance] = useState(balance);
  const [shouldAnimate, setShouldAnimate] = useState(false);
  
  const estado: EstadoFinanciero = determinarEstadoFinanciero(totalIngresos, totalEgresos, balance);
  const emojiEstado = getEmojiEstado(estado);
  const mensaje = getMensajeMotivacional(estado);

  // Animación cuando cambia el balance
  useEffect(() => {
    if (balance !== previousBalance) {
      setShouldAnimate(true);
      const timer = setTimeout(() => setShouldAnimate(false), 200);
      setPreviousBalance(balance);
      return () => clearTimeout(timer);
    }
  }, [balance, previousBalance]);

  // Estilos según el estado financiero
  const colorClasses = {
    saludable: 'text-exito',
    precaucion: 'text-alerta-precaucion',
    riesgo: 'text-egreso',
  };

  const borderClasses = {
    saludable: 'border-exito/20',
    precaucion: 'border-alerta-precaucion/20',
    riesgo: 'border-egreso/20',
  };

  return (
    <Card 
      className={`border-2 ${borderClasses[estado]} ${balance < 0 ? 'animate-shake' : ''} animate-fade-in-up`}
      data-testid="card-balance"
    >
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
        <CardTitle className="text-base sm:text-lg font-semibold">
          Balance Total
        </CardTitle>
        <span className="text-3xl sm:text-4xl" aria-hidden="true">
          {emojiEstado}
        </span>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Monto del balance */}
        <div 
          className={`font-mono text-3xl sm:text-4xl lg:text-5xl font-bold ${colorClasses[estado]} ${shouldAnimate ? 'animate-pulse-subtle' : ''}`}
          data-testid="text-balance-amount"
        >
          ${balance.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </div>

        {/* Mensaje motivacional */}
        <div className="flex items-start gap-2 p-3 rounded-md bg-muted/50">
          <span className="text-xl flex-shrink-0" aria-hidden="true">
            {mensaje.emoji}
          </span>
          <p 
            className="text-sm text-muted-foreground leading-relaxed"
            data-testid="text-motivational-message"
          >
            {mensaje.mensaje}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
