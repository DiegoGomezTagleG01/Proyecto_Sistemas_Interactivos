import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Volume2, Palette } from 'lucide-react';
import { useThemeContext } from './ThemeProvider';

interface SettingsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  sonidosHabilitados: boolean;
  volumen: number;
  onSonidosChange: (enabled: boolean) => void;
  onVolumenChange: (volume: number) => void;
}

/**
 * Modal de configuración de la aplicación
 * Permite cambiar tema, sonidos y volumen
 */
export function SettingsModal({
  open,
  onOpenChange,
  sonidosHabilitados,
  volumen,
  onSonidosChange,
  onVolumenChange,
}: SettingsModalProps) {
  const { theme, toggleTheme } = useThemeContext();

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]" data-testid="modal-settings">
        <DialogHeader>
          <DialogTitle className="text-2xl">Configuración</DialogTitle>
          <DialogDescription>
            Personaliza tu experiencia en el simulador de finanzas
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="appearance" className="mt-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="appearance" data-testid="tab-appearance">
              <Palette className="h-4 w-4 mr-2" />
              Apariencia
            </TabsTrigger>
            <TabsTrigger value="sound" data-testid="tab-sound">
              <Volume2 className="h-4 w-4 mr-2" />
              Sonido
            </TabsTrigger>
          </TabsList>

          {/* Pestaña de Apariencia */}
          <TabsContent value="appearance" className="space-y-6 mt-6">
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-semibold mb-3">Tema de Color</h3>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="space-y-0.5">
                    <Label htmlFor="theme-toggle" className="text-base font-medium">
                      Modo Oscuro
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      {theme === 'dark' ? 'Activado' : 'Desactivado'}
                    </p>
                  </div>
                  <Switch
                    id="theme-toggle"
                    checked={theme === 'dark'}
                    onCheckedChange={toggleTheme}
                    data-testid="switch-theme"
                  />
                </div>
              </div>

              <div className="p-4 bg-muted/50 rounded-lg">
                <p className="text-sm text-muted-foreground">
                  El tema oscuro reduce el cansancio visual en ambientes con poca luz
                  y puede ayudar a ahorrar batería en pantallas OLED.
                </p>
              </div>
            </div>
          </TabsContent>

          {/* Pestaña de Sonido */}
          <TabsContent value="sound" className="space-y-6 mt-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="space-y-0.5">
                  <Label htmlFor="sound-toggle" className="text-base font-medium">
                    Efectos de Sonido
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    {sonidosHabilitados ? 'Activados' : 'Desactivados'}
                  </p>
                </div>
                <Switch
                  id="sound-toggle"
                  checked={sonidosHabilitados}
                  onCheckedChange={onSonidosChange}
                  data-testid="switch-sound"
                />
              </div>

              {/* Control de volumen */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label htmlFor="volume-slider" className="text-base font-medium">
                    Volumen
                  </Label>
                  <span className="text-sm font-mono text-muted-foreground">
                    {volumen}%
                  </span>
                </div>
                <Slider
                  id="volume-slider"
                  value={[volumen]}
                  onValueChange={(value) => onVolumenChange(value[0])}
                  max={100}
                  step={5}
                  disabled={!sonidosHabilitados}
                  data-testid="slider-volume"
                  className="w-full"
                />
              </div>

              <div className="p-4 bg-muted/50 rounded-lg">
                <p className="text-sm text-muted-foreground">
                  Los efectos de sonido te dan retroalimentación inmediata cuando
                  registras transacciones y desbloqueas logros.
                </p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
