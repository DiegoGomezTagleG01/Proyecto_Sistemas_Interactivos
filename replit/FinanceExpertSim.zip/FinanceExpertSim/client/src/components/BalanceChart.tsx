import { useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingUp } from 'lucide-react';

interface BalanceChartProps {
  transaccionesPorDia: { fecha: string; balance: number }[];
}

/**
 * Gráfica de líneas que muestra la evolución del balance en el tiempo
 * Usa Chart.js para renderizado dinámico
 */
export function BalanceChart({ transaccionesPorDia }: BalanceChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<any>(null);

  useEffect(() => {
    if (!canvasRef.current || typeof window === 'undefined' || !(window as any).Chart) return;

    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    // Destruir gráfica anterior si existe
    if (chartRef.current) {
      chartRef.current.destroy();
    }

    // Obtener tema actual
    const isDark = document.documentElement.classList.contains('dark');
    const gridColor = isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)';
    const textColor = isDark ? 'rgba(255, 255, 255, 0.7)' : 'rgba(0, 0, 0, 0.7)';

    // Preparar datos
    const labels = transaccionesPorDia.map(t => {
      const fecha = new Date(t.fecha);
      return fecha.toLocaleDateString('es-MX', { month: 'short', day: 'numeric' });
    });
    
    const data = transaccionesPorDia.map(t => t.balance);

    // Crear nueva gráfica
    const Chart = (window as any).Chart;
    chartRef.current = new Chart(ctx, {
      type: 'line',
      data: {
        labels,
        datasets: [{
          label: 'Balance',
          data,
          borderColor: 'hsl(142, 76%, 36%)',
          backgroundColor: (context: any) => {
            const ctx = context.chart.ctx;
            const gradient = ctx.createLinearGradient(0, 0, 0, 300);
            gradient.addColorStop(0, 'rgba(16, 185, 129, 0.2)');
            gradient.addColorStop(1, 'rgba(16, 185, 129, 0)');
            return gradient;
          },
          fill: true,
          tension: 0.4,
          pointBackgroundColor: 'hsl(142, 76%, 36%)',
          pointBorderColor: '#fff',
          pointBorderWidth: 2,
          pointRadius: 4,
          pointHoverRadius: 6,
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          },
          tooltip: {
            backgroundColor: isDark ? 'rgba(0, 0, 0, 0.8)' : 'rgba(255, 255, 255, 0.9)',
            titleColor: textColor,
            bodyColor: textColor,
            borderColor: gridColor,
            borderWidth: 1,
            padding: 12,
            displayColors: false,
            callbacks: {
              label: function(context: any) {
                return `Balance: $${context.parsed.y.toLocaleString('es-MX', { minimumFractionDigits: 2 })}`;
              }
            }
          }
        },
        scales: {
          x: {
            grid: {
              color: gridColor,
              drawBorder: false,
            },
            ticks: {
              color: textColor,
              maxRotation: 45,
              minRotation: 45,
            }
          },
          y: {
            grid: {
              color: gridColor,
              drawBorder: false,
            },
            ticks: {
              color: textColor,
              callback: function(value: any) {
                return '$' + value.toLocaleString('es-MX');
              }
            },
            beginAtZero: true,
          }
        },
        interaction: {
          intersect: false,
          mode: 'index',
        },
      }
    });

    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
      }
    };
  }, [transaccionesPorDia]);

  return (
    <Card className="animate-fade-in-up" style={{ animationDelay: '100ms' }}>
      <CardHeader>
        <CardTitle className="text-lg sm:text-xl flex items-center gap-2">
          <TrendingUp className="h-5 w-5" />
          Evolución del Balance
        </CardTitle>
      </CardHeader>
      <CardContent>
        {transaccionesPorDia.length === 0 ? (
          <div className="h-[250px] sm:h-[300px] flex items-center justify-center text-muted-foreground">
            <div className="text-center space-y-2">
              <div className="text-4xl">📊</div>
              <p className="text-sm">Agrega transacciones para ver tu evolución</p>
            </div>
          </div>
        ) : (
          <div className="h-[250px] sm:h-[300px]">
            <canvas ref={canvasRef} data-testid="chart-balance-evolution"></canvas>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
