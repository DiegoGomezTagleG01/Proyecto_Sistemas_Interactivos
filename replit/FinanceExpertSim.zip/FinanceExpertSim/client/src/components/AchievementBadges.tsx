import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Trophy, Lock } from 'lucide-react';
import { LOGROS_DISPONIBLES, getDefinicionLogro } from '@/lib/logrosData';

interface AchievementBadgesProps {
  logrosDesbloqueados: string[];
}

/**
 * Componente que muestra los logros del usuario
 * Badges desbloqueados en color, bloqueados en gris
 */
export function AchievementBadges({ logrosDesbloqueados }: AchievementBadgesProps) {
  return (
    <Card className="animate-fade-in-up" style={{ animationDelay: '300ms' }}>
      <CardHeader>
        <CardTitle className="text-lg sm:text-xl flex items-center gap-2">
          <Trophy className="h-5 w-5 text-alerta-precaucion" />
          Logros Desbloqueados
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {LOGROS_DISPONIBLES.map((logro) => {
            const desbloqueado = logrosDesbloqueados.includes(logro.codigo);
            
            return (
              <div
                key={logro.codigo}
                className={`p-4 rounded-lg border-2 transition-all ${
                  desbloqueado
                    ? 'bg-exito/10 border-exito/30'
                    : 'bg-muted/30 border-border opacity-60'
                }`}
                data-testid={`badge-logro-${logro.codigo}`}
              >
                <div className="flex items-start gap-3">
                  <div className="text-3xl flex-shrink-0">
                    {desbloqueado ? logro.emoji : <Lock className="h-7 w-7 text-muted-foreground" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-semibold text-sm">{logro.titulo}</h4>
                      {desbloqueado && (
                        <Badge variant="default" className="text-xs">
                          ✓
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      {logro.descripcion}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Contador de logros */}
        <div className="mt-4 pt-4 border-t border-border">
          <div className="text-center">
            <p className="text-sm text-muted-foreground">
              Has desbloqueado{' '}
              <span className="font-bold text-foreground font-mono">
                {logrosDesbloqueados.length}
              </span>
              {' '}de{' '}
              <span className="font-bold text-foreground font-mono">
                {LOGROS_DISPONIBLES.length}
              </span>
              {' '}logros
            </p>
            <div className="mt-2 w-full bg-muted rounded-full h-2 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-exito to-alerta-precaucion transition-all duration-500"
                style={{
                  width: `${(logrosDesbloqueados.length / LOGROS_DISPONIBLES.length) * 100}%`
                }}
              />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
