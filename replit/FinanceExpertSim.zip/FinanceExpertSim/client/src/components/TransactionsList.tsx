import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { List } from 'lucide-react';
import { getEmojiCategoria } from '@/lib/categoriasData';
import type { Transaccion } from '@shared/schema';

interface TransactionsListProps {
  transacciones: Transaccion[];
}

/**
 * Lista de transacciones recientes
 * Muestra las últimas transacciones con colores diferenciados
 */
export function TransactionsList({ transacciones }: TransactionsListProps) {
  // Ordenar por fecha descendente (más recientes primero)
  const transaccionesOrdenadas = [...transacciones].sort((a, b) => {
    return new Date(b.fecha).getTime() - new Date(a.fecha).getTime();
  });

  // Mostrar solo las últimas 10
  const transaccionesRecientes = transaccionesOrdenadas.slice(0, 10);

  return (
    <Card className="animate-fade-in-up" style={{ animationDelay: '400ms' }}>
      <CardHeader>
        <CardTitle className="text-lg sm:text-xl flex items-center gap-2">
          <List className="h-5 w-5" />
          Transacciones Recientes
        </CardTitle>
      </CardHeader>
      <CardContent>
        {transaccionesRecientes.length === 0 ? (
          <div className="py-12 text-center text-muted-foreground">
            <div className="text-4xl mb-2">📝</div>
            <p className="text-sm">No hay transacciones registradas</p>
          </div>
        ) : (
          <ScrollArea className="h-[300px] pr-4">
            <div className="space-y-3">
              {transaccionesRecientes.map((transaccion) => {
                const emoji = getEmojiCategoria(transaccion.categoria);
                const monto = parseFloat(transaccion.monto.toString());
                const fecha = new Date(transaccion.fecha);
                const esIngreso = transaccion.tipo === 'ingreso';

                return (
                  <div
                    key={transaccion.id}
                    className={`p-3 rounded-lg border ${
                      esIngreso
                        ? 'bg-ingreso/5 border-ingreso/20'
                        : 'bg-egreso/5 border-egreso/20'
                    } hover-elevate`}
                    data-testid={`transaction-item-${transaccion.id}`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-3 flex-1 min-w-0">
                        <div className="text-2xl flex-shrink-0">{emoji}</div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className="font-semibold text-sm truncate">
                              {transaccion.categoria}
                            </h4>
                            <Badge
                              variant={esIngreso ? 'default' : 'destructive'}
                              className="text-xs flex-shrink-0"
                            >
                              {esIngreso ? '↑ Ingreso' : '↓ Egreso'}
                            </Badge>
                          </div>
                          {transaccion.descripcion && (
                            <p className="text-xs text-muted-foreground line-clamp-1">
                              {transaccion.descripcion}
                            </p>
                          )}
                          <p className="text-xs text-muted-foreground mt-1">
                            {fecha.toLocaleDateString('es-MX', {
                              year: 'numeric',
                              month: 'long',
                              day: 'numeric'
                            })}
                          </p>
                        </div>
                      </div>
                      <div
                        className={`font-mono font-bold text-sm sm:text-base flex-shrink-0 ${
                          esIngreso ? 'text-ingreso' : 'text-egreso'
                        }`}
                      >
                        {esIngreso ? '+' : '-'}$
                        {monto.toLocaleString('es-MX', { minimumFractionDigits: 2 })}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
}
