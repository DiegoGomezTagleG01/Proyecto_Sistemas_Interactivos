import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { insertTransaccionSchema, type InsertTransaccion } from '@shared/schema';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { getCategoriasPorTipo, getEmojiCategoria } from '@/lib/categoriasData';
import { Plus } from 'lucide-react';
import { useState } from 'react';

interface TransactionFormProps {
  onSubmit: (data: InsertTransaccion) => Promise<void>;
  isPending: boolean;
}

/**
 * Formulario para registrar nuevas transacciones
 * Incluye validación con Zod y campos dinámicos según el tipo
 */
export function TransactionForm({ onSubmit, isPending }: TransactionFormProps) {
  const [tipoSeleccionado, setTipoSeleccionado] = useState<'ingreso' | 'egreso'>('egreso');
  
  const form = useForm<InsertTransaccion>({
    resolver: zodResolver(insertTransaccionSchema),
    defaultValues: {
      tipo: 'egreso',
      categoria: '',
      monto: '',
      descripcion: '',
      fecha: new Date().toISOString().split('T')[0],
    },
  });

  const handleSubmit = async (data: InsertTransaccion) => {
    await onSubmit(data);
    form.reset({
      tipo: tipoSeleccionado,
      categoria: '',
      monto: '',
      descripcion: '',
      fecha: new Date().toISOString().split('T')[0],
    });
  };

  const categorias = getCategoriasPorTipo(tipoSeleccionado);

  return (
    <Card className="animate-fade-in-up">
      <CardHeader>
        <CardTitle className="text-xl sm:text-2xl flex items-center gap-2">
          <Plus className="h-5 w-5 sm:h-6 sm:w-6" />
          Registrar Transacción
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            {/* Tipo de transacción (Radio buttons) */}
            <FormField
              control={form.control}
              name="tipo"
              render={({ field }) => (
                <FormItem className="space-y-3">
                  <FormLabel className="text-sm font-semibold">Tipo de Transacción</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={(value) => {
                        field.onChange(value);
                        setTipoSeleccionado(value as 'ingreso' | 'egreso');
                        form.setValue('categoria', '');
                      }}
                      value={field.value}
                      className="flex gap-4"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem 
                          value="ingreso" 
                          id="ingreso"
                          data-testid="radio-ingreso"
                          className="border-ingreso text-ingreso"
                        />
                        <label
                          htmlFor="ingreso"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                        >
                          <span className="mr-1">📈</span>
                          Ingreso
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem 
                          value="egreso" 
                          id="egreso"
                          data-testid="radio-egreso"
                          className="border-egreso text-egreso"
                        />
                        <label
                          htmlFor="egreso"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                        >
                          <span className="mr-1">📉</span>
                          Egreso
                        </label>
                      </div>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Categoría (Select con emojis) */}
            <FormField
              control={form.control}
              name="categoria"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-semibold">Categoría</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-categoria">
                        <SelectValue placeholder="Selecciona una categoría" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {categorias.map((cat) => (
                        <SelectItem 
                          key={cat.nombre} 
                          value={cat.nombre}
                          data-testid={`option-categoria-${cat.nombre.toLowerCase().replace(/\s+/g, '-')}`}
                        >
                          <span className="flex items-center gap-2">
                            <span>{cat.emoji}</span>
                            <span>{cat.nombre}</span>
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Monto */}
            <FormField
              control={form.control}
              name="monto"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-semibold">Monto</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                        $
                      </span>
                      <Input
                        type="number"
                        step="0.01"
                        placeholder="0.00"
                        className="pl-7 font-mono"
                        data-testid="input-monto"
                        {...field}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Fecha */}
            <FormField
              control={form.control}
              name="fecha"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-semibold">Fecha</FormLabel>
                  <FormControl>
                    <Input
                      type="date"
                      data-testid="input-fecha"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Descripción (opcional) */}
            <FormField
              control={form.control}
              name="descripcion"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-semibold">
                    Descripción <span className="text-muted-foreground font-normal">(opcional)</span>
                  </FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Ej: Compra de mercado semanal"
                      className="resize-none"
                      rows={3}
                      data-testid="input-descripcion"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Botón submit */}
            <Button
              type="submit"
              className="w-full"
              size="lg"
              disabled={isPending}
              data-testid="button-submit-transaction"
            >
              {isPending ? 'Guardando...' : 'Agregar Transacción'}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
