import { useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PieChart } from 'lucide-react';

interface CategoryChartProps {
  gastosPorCategoria: { categoria: string; monto: number; emoji: string }[];
}

/**
 * Gráfica de dona que muestra la distribución de gastos por categoría
 * Incluye colores distintivos y emojis en la leyenda
 */
export function CategoryChart({ gastosPorCategoria }: CategoryChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<any>(null);

  useEffect(() => {
    if (!canvasRef.current || typeof window === 'undefined' || !(window as any).Chart) return;

    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    // Destruir gráfica anterior si existe
    if (chartRef.current) {
      chartRef.current.destroy();
    }

    // Obtener tema actual
    const isDark = document.documentElement.classList.contains('dark');
    const textColor = isDark ? 'rgba(255, 255, 255, 0.9)' : 'rgba(0, 0, 0, 0.9)';

    // Preparar datos
    const labels = gastosPorCategoria.map(g => `${g.emoji} ${g.categoria}`);
    const data = gastosPorCategoria.map(g => g.monto);

    // Colores vibrantes para cada categoría
    const colors = [
      'rgba(239, 68, 68, 0.8)',   // Rojo
      'rgba(249, 115, 22, 0.8)',  // Naranja
      'rgba(245, 158, 11, 0.8)',  // Amarillo
      'rgba(34, 197, 94, 0.8)',   // Verde
      'rgba(59, 130, 246, 0.8)',  // Azul
      'rgba(147, 51, 234, 0.8)',  // Púrpura
      'rgba(236, 72, 153, 0.8)',  // Rosa
      'rgba(20, 184, 166, 0.8)',  // Teal
      'rgba(251, 146, 60, 0.8)',  // Naranja claro
    ];

    // Crear nueva gráfica
    const Chart = (window as any).Chart;
    chartRef.current = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels,
        datasets: [{
          data,
          backgroundColor: colors.slice(0, data.length),
          borderColor: isDark ? '#1f2937' : '#ffffff',
          borderWidth: 3,
          hoverOffset: 10,
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              color: textColor,
              padding: 15,
              font: {
                size: 12,
              },
              generateLabels: function(chart: any) {
                const data = chart.data;
                if (data.labels.length && data.datasets.length) {
                  return data.labels.map((label: string, i: number) => {
                    const value = data.datasets[0].data[i];
                    const total = data.datasets[0].data.reduce((a: number, b: number) => a + b, 0);
                    const percentage = ((value / total) * 100).toFixed(1);
                    
                    return {
                      text: `${label} (${percentage}%)`,
                      fillStyle: data.datasets[0].backgroundColor[i],
                      hidden: false,
                      index: i
                    };
                  });
                }
                return [];
              }
            }
          },
          tooltip: {
            backgroundColor: isDark ? 'rgba(0, 0, 0, 0.8)' : 'rgba(255, 255, 255, 0.9)',
            titleColor: textColor,
            bodyColor: textColor,
            borderColor: 'rgba(0, 0, 0, 0.1)',
            borderWidth: 1,
            padding: 12,
            callbacks: {
              label: function(context: any) {
                const value = context.parsed;
                const total = context.dataset.data.reduce((a: number, b: number) => a + b, 0);
                const percentage = ((value / total) * 100).toFixed(1);
                return `$${value.toLocaleString('es-MX', { minimumFractionDigits: 2 })} (${percentage}%)`;
              }
            }
          }
        },
        cutout: '65%',
      }
    });

    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
      }
    };
  }, [gastosPorCategoria]);

  return (
    <Card className="animate-fade-in-up" style={{ animationDelay: '200ms' }}>
      <CardHeader>
        <CardTitle className="text-lg sm:text-xl flex items-center gap-2">
          <PieChart className="h-5 w-5" />
          Gastos por Categoría
        </CardTitle>
      </CardHeader>
      <CardContent>
        {gastosPorCategoria.length === 0 ? (
          <div className="h-[300px] sm:h-[350px] flex items-center justify-center text-muted-foreground">
            <div className="text-center space-y-2">
              <div className="text-4xl">📊</div>
              <p className="text-sm">Registra gastos para ver su distribución</p>
            </div>
          </div>
        ) : (
          <div className="h-[300px] sm:h-[350px]">
            <canvas ref={canvasRef} data-testid="chart-category-distribution"></canvas>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
