import { useState } from 'react';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { useToast } from '@/hooks/use-toast';
import { Header } from '@/components/Header';
import { BalanceCard } from '@/components/BalanceCard';
import { IncomeExpenseCards } from '@/components/IncomeExpenseCards';
import { TransactionForm } from '@/components/TransactionForm';
import { BalanceChart } from '@/components/BalanceChart';
import { CategoryChart } from '@/components/CategoryChart';
import { AchievementBadges } from '@/components/AchievementBadges';
import { TransactionsList } from '@/components/TransactionsList';
import { SettingsModal } from '@/components/SettingsModal';
import type { Transaccion, InsertTransaccion, EstadisticasFinancieras } from '@shared/schema';
import { verificarLogros } from '@/lib/logrosData';
import { determinarEstadoFinanciero } from '@/lib/mensajesMotivacionales';

/**
 * Página principal del dashboard
 * Integra todos los componentes y gestiona el estado con LocalStorage
 */
export default function Dashboard() {
  const { toast } = useToast();
  const [settingsOpen, setSettingsOpen] = useState(false);
  
  // Estado persistido en LocalStorage
  const [transacciones, setTransacciones] = useLocalStorage<Transaccion[]>('finanzas-transacciones', []);
  const [logrosDesbloqueados, setLogrosDesbloqueados] = useLocalStorage<string[]>('finanzas-logros', []);
  const [sonidosHabilitados, setSonidosHabilitados] = useLocalStorage('finanzas-sonidos', true);
  const [volumen, setVolumen] = useLocalStorage('finanzas-volumen', 50);
  
  // Estado local
  const [isPending, setIsPending] = useState(false);

  // Calcular estadísticas financieras
  const calcularEstadisticas = (): EstadisticasFinancieras => {
    const totalIngresos = transacciones
      .filter(t => t.tipo === 'ingreso')
      .reduce((sum, t) => sum + parseFloat(t.monto.toString()), 0);

    const totalEgresos = transacciones
      .filter(t => t.tipo === 'egreso')
      .reduce((sum, t) => sum + parseFloat(t.monto.toString()), 0);

    const balance = totalIngresos - totalEgresos;

    // Agrupar transacciones por día para la gráfica
    const transaccionesPorDia: { fecha: string; balance: number }[] = [];
    const diasUnicos = new Set(
      transacciones.map(t => new Date(t.fecha).toISOString().split('T')[0])
    );

    // Ordenar fechas
    const fechasOrdenadas = Array.from(diasUnicos).sort();

    let balanceAcumulado = 0;
    fechasOrdenadas.forEach(fecha => {
      const transaccionesDia = transacciones.filter(
        t => new Date(t.fecha).toISOString().split('T')[0] === fecha
      );

      const balanceDia = transaccionesDia.reduce((sum, t) => {
        const monto = parseFloat(t.monto.toString());
        return sum + (t.tipo === 'ingreso' ? monto : -monto);
      }, 0);

      balanceAcumulado += balanceDia;
      transaccionesPorDia.push({ fecha, balance: balanceAcumulado });
    });

    // Agrupar gastos por categoría
    const gastosPorCategoriaMap = new Map<string, { monto: number; emoji: string }>();
    
    transacciones
      .filter(t => t.tipo === 'egreso')
      .forEach(t => {
        const monto = parseFloat(t.monto.toString());
        const actual = gastosPorCategoriaMap.get(t.categoria) || { monto: 0, emoji: '' };
        gastosPorCategoriaMap.set(t.categoria, {
          monto: actual.monto + monto,
          emoji: actual.emoji || t.categoria // Emoji se obtiene del componente
        });
      });

    const gastosPorCategoria = Array.from(gastosPorCategoriaMap.entries()).map(
      ([categoria, data]) => ({
        categoria,
        monto: data.monto,
        emoji: data.emoji
      })
    );

    return {
      totalIngresos,
      totalEgresos,
      balance,
      transaccionesPorDia,
      gastosPorCategoria,
    };
  };

  const stats = calcularEstadisticas();

  // Reproducir sonido
  const reproducirSonido = (tipo: 'exito' | 'logro' | 'alerta') => {
    if (!sonidosHabilitados || typeof window === 'undefined' || !(window as any).Howl) return;

    // Frecuencias para diferentes tipos de sonidos
    const frecuencias: { [key: string]: number[] } = {
      exito: [523.25, 659.25],      // Do, Mi
      logro: [523.25, 659.25, 783.99], // Do, Mi, Sol
      alerta: [440, 415.30],         // La, Sol#
    };

    // Crear sonidos con Web Audio API (fallback si Howler no está disponible)
    try {
      const AudioContext = (window as any).AudioContext || (window as any).webkitAudioContext;
      const audioContext = new AudioContext();
      const gainNode = audioContext.createGain();
      gainNode.connect(audioContext.destination);
      gainNode.gain.value = volumen / 200; // Reducir volumen a la mitad del configurado

      const freqs = frecuencias[tipo];
      freqs.forEach((freq, index) => {
        const oscillator = audioContext.createOscillator();
        oscillator.connect(gainNode);
        oscillator.frequency.value = freq;
        oscillator.type = 'sine';
        oscillator.start(audioContext.currentTime + index * 0.1);
        oscillator.stop(audioContext.currentTime + index * 0.1 + 0.2);
      });
    } catch (error) {
      console.log('No se pudo reproducir el sonido');
    }
  };

  // Verificar y desbloquear nuevos logros
  const verificarNuevosLogros = () => {
    const logrosActuales = verificarLogros(stats, transacciones);
    const nuevosLogros = logrosActuales.filter(
      codigo => !logrosDesbloqueados.includes(codigo)
    );

    if (nuevosLogros.length > 0) {
      setLogrosDesbloqueados(logrosActuales);
      
      // Mostrar celebración por cada logro nuevo
      nuevosLogros.forEach(codigo => {
        const logro = require('@/lib/logrosData').getDefinicionLogro(codigo);
        if (logro) {
          reproducirSonido('logro');
          
          // Confetti si está disponible
          if (typeof window !== 'undefined' && (window as any).confetti) {
            (window as any).confetti({
              particleCount: 100,
              spread: 70,
              origin: { y: 0.6 }
            });
          }

          toast({
            title: `${logro.emoji} ¡Logro Desbloqueado!`,
            description: `${logro.titulo}: ${logro.descripcion}`,
            duration: 7000,
          });
        }
      });
    }
  };

  // Manejar envío de nueva transacción
  const handleSubmitTransaccion = async (data: InsertTransaccion) => {
    setIsPending(true);
    
    try {
      // Simular delay de red
      await new Promise(resolve => setTimeout(resolve, 300));

      // Crear nueva transacción con ID único
      const nuevaTransaccion: Transaccion = {
        id: `txn_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        tipo: data.tipo,
        categoria: data.categoria,
        monto: data.monto,
        descripcion: data.descripcion || '',
        fecha: data.fecha ? new Date(data.fecha) : new Date(),
      };

      // Agregar a la lista de transacciones
      setTransacciones([...transacciones, nuevaTransaccion]);

      // Reproducir sonido de éxito
      reproducirSonido('exito');

      // Mostrar notificación
      toast({
        title: "✅ Transacción registrada",
        description: `${data.tipo === 'ingreso' ? 'Ingreso' : 'Egreso'} de $${parseFloat(data.monto).toLocaleString('es-MX')} agregado exitosamente`,
        duration: 3000,
      });

      // Verificar logros después de un pequeño delay para permitir que se actualicen las estadísticas
      setTimeout(() => {
        verificarNuevosLogros();
      }, 500);

    } catch (error) {
      toast({
        title: "❌ Error",
        description: "No se pudo registrar la transacción",
        variant: "destructive",
      });
    } finally {
      setIsPending(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header onOpenSettings={() => setSettingsOpen(true)} />

      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {/* Grid principal: Formulario + Visualización */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8">
          {/* Columna izquierda: Formulario (33%) */}
          <div className="lg:col-span-1 space-y-6">
            <TransactionForm 
              onSubmit={handleSubmitTransaccion}
              isPending={isPending}
            />
          </div>

          {/* Columna derecha: Visualización (67%) */}
          <div className="lg:col-span-2 space-y-6">
            {/* Tarjeta de balance principal */}
            <BalanceCard
              balance={stats.balance}
              totalIngresos={stats.totalIngresos}
              totalEgresos={stats.totalEgresos}
            />

            {/* Tarjetas de ingresos y egresos */}
            <IncomeExpenseCards
              totalIngresos={stats.totalIngresos}
              totalEgresos={stats.totalEgresos}
            />

            {/* Gráficas */}
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              <BalanceChart transaccionesPorDia={stats.transaccionesPorDia} />
              <CategoryChart gastosPorCategoria={stats.gastosPorCategoria} />
            </div>

            {/* Lista de transacciones recientes */}
            <TransactionsList transacciones={transacciones} />

            {/* Logros desbloqueados */}
            <AchievementBadges logrosDesbloqueados={logrosDesbloqueados} />
          </div>
        </div>
      </main>

      {/* Modal de configuración */}
      <SettingsModal
        open={settingsOpen}
        onOpenChange={setSettingsOpen}
        sonidosHabilitados={sonidosHabilitados}
        volumen={volumen}
        onSonidosChange={setSonidosHabilitados}
        onVolumenChange={setVolumen}
      />
    </div>
  );
}
