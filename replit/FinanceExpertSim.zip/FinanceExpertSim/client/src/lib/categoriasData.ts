import type { CategoriaDefinida } from "@shared/schema";

// Categorías predefinidas del sistema
export const CATEGORIAS_INGRESO: CategoriaDefinida[] = [
  { nombre: "Salario", emoji: "💰", tipo: "ingreso" },
  { nombre: "Freelance", emoji: "💼", tipo: "ingreso" },
  { nombre: "Inversiones", emoji: "📈", tipo: "ingreso" },
  { nombre: "Regalo", emoji: "🎁", tipo: "ingreso" },
  { nombre: "Venta", emoji: "🏷️", tipo: "ingreso" },
  { nombre: "Otros Ingresos", emoji: "💵", tipo: "ingreso" },
];

export const CATEGORIAS_EGRESO: CategoriaDefinida[] = [
  { nombre: "Comida", emoji: "🍕", tipo: "egreso" },
  { nombre: "Vivienda", emoji: "🏠", tipo: "egreso" },
  { nombre: "Transporte", emoji: "🚗", tipo: "egreso" },
  { nombre: "Entretenimiento", emoji: "🎉", tipo: "egreso" },
  { nombre: "Salud", emoji: "🏥", tipo: "egreso" },
  { nombre: "Educación", emoji: "📚", tipo: "egreso" },
  { nombre: "Compras", emoji: "🛍️", tipo: "egreso" },
  { nombre: "Servicios", emoji: "💳", tipo: "egreso" },
  { nombre: "Otros Gastos", emoji: "💸", tipo: "egreso" },
];

export const TODAS_LAS_CATEGORIAS = [...CATEGORIAS_INGRESO, ...CATEGORIAS_EGRESO];

// Obtener categorías por tipo
export function getCategoriasPorTipo(tipo: 'ingreso' | 'egreso'): CategoriaDefinida[] {
  return tipo === 'ingreso' ? CATEGORIAS_INGRESO : CATEGORIAS_EGRESO;
}

// Obtener emoji de categoría
export function getEmojiCategoria(nombreCategoria: string): string {
  const categoria = TODAS_LAS_CATEGORIAS.find(c => c.nombre === nombreCategoria);
  return categoria?.emoji || "💰";
}
