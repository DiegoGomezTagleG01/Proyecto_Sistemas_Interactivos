import type { DefinicionLogro, EstadisticasFinancieras, Transaccion } from "@shared/schema";

// Definiciones de todos los logros disponibles en el sistema
export const LOGROS_DISPONIBLES: DefinicionLogro[] = [
  {
    codigo: "ahorrista_7dias",
    titulo: "Ahorrista Nivel 1",
    descripcion: "Mantén tu balance positivo durante 7 días consecutivos",
    emoji: "💎",
    criterio: (stats, transacciones) => {
      // Verificar si los últimos 7 días tienen balance positivo
      const hoy = new Date();
      const hace7Dias = new Date(hoy.getTime() - 7 * 24 * 60 * 60 * 1000);
      
      const transaccionesRecientes = transacciones.filter(t => {
        const fecha = new Date(t.fecha);
        return fecha >= hace7Dias;
      });

      if (transaccionesRecientes.length === 0) return false;

      // Calcular balance acumulado por día
      const balancePorDia: { [key: string]: number } = {};
      transaccionesRecientes.forEach(t => {
        const fecha = new Date(t.fecha).toISOString().split('T')[0];
        if (!balancePorDia[fecha]) balancePorDia[fecha] = 0;
        const monto = parseFloat(t.monto.toString());
        balancePorDia[fecha] += t.tipo === 'ingreso' ? monto : -monto;
      });

      // Verificar que todos los días tengan balance positivo
      const balances = Object.values(balancePorDia);
      return balances.length >= 7 && balances.every(b => b > 0);
    }
  },
  {
    codigo: "guardian_30dias",
    titulo: "Guardián del Ahorro",
    descripcion: "Mantén tu balance positivo durante 30 días consecutivos",
    emoji: "🏆",
    criterio: (stats, transacciones) => {
      const hoy = new Date();
      const hace30Dias = new Date(hoy.getTime() - 30 * 24 * 60 * 60 * 1000);
      
      const transaccionesRecientes = transacciones.filter(t => {
        const fecha = new Date(t.fecha);
        return fecha >= hace30Dias;
      });

      if (transaccionesRecientes.length === 0) return false;

      const balancePorDia: { [key: string]: number } = {};
      transaccionesRecientes.forEach(t => {
        const fecha = new Date(t.fecha).toISOString().split('T')[0];
        if (!balancePorDia[fecha]) balancePorDia[fecha] = 0;
        const monto = parseFloat(t.monto.toString());
        balancePorDia[fecha] += t.tipo === 'ingreso' ? monto : -monto;
      });

      const balances = Object.values(balancePorDia);
      return balances.length >= 30 && balances.every(b => b > 0);
    }
  },
  {
    codigo: "maestro_financiero",
    titulo: "Maestro Financiero",
    descripcion: "Alcanza un balance total superior a $10,000",
    emoji: "👑",
    criterio: (stats) => {
      return stats.balance >= 10000;
    }
  },
  {
    codigo: "primer_paso",
    titulo: "Primer Paso",
    descripcion: "Registra tu primera transacción",
    emoji: "🌟",
    criterio: (stats, transacciones) => {
      return transacciones.length >= 1;
    }
  },
  {
    codigo: "organizador",
    titulo: "Organizador",
    descripcion: "Registra 50 transacciones",
    emoji: "📊",
    criterio: (stats, transacciones) => {
      return transacciones.length >= 50;
    }
  },
];

// Verificar qué logros debería desbloquear el usuario
export function verificarLogros(
  stats: EstadisticasFinancieras,
  transacciones: Transaccion[]
): string[] {
  const logrosDesbloqueados: string[] = [];
  
  LOGROS_DISPONIBLES.forEach(logro => {
    if (logro.criterio(stats, transacciones)) {
      logrosDesbloqueados.push(logro.codigo);
    }
  });
  
  return logrosDesbloqueados;
}

// Obtener definición de un logro por código
export function getDefinicionLogro(codigo: string): DefinicionLogro | undefined {
  return LOGROS_DISPONIBLES.find(l => l.codigo === codigo);
}
