import type { EstadoFinanciero, MensajeMotivacional } from "@shared/schema";

// Mensajes motivacionales organizados por estado financiero
const MENSAJES_SALUDABLE: MensajeMotivacional[] = [
  { tipo: "saludable", mensaje: "¡Excelente! Sigues en positivo, sigue así", emoji: "💪" },
  { tipo: "saludable", mensaje: "¡Vas muy bien! Tu balance es saludable", emoji: "😊" },
  { tipo: "saludable", mensaje: "¡Increíble! Tus finanzas están en orden", emoji: "✨" },
  { tipo: "saludable", mensaje: "¡Felicidades! Estás ahorrando exitosamente", emoji: "🎉" },
  { tipo: "saludable", mensaje: "¡Sigue así! Tus finanzas lucen excelentes", emoji: "🌟" },
];

const MENSAJES_PRECAUCION: MensajeMotivacional[] = [
  { tipo: "precaucion", mensaje: "Atención: tus gastos están alcanzando el 70% de tus ingresos", emoji: "⚠️" },
  { tipo: "precaucion", mensaje: "Cuidado, tus gastos están aumentando esta semana", emoji: "⚠️" },
  { tipo: "precaucion", mensaje: "Considera reducir gastos innecesarios pronto", emoji: "💡" },
  { tipo: "precaucion", mensaje: "Tus gastos son altos, revisa tu presupuesto", emoji: "📊" },
];

const MENSAJES_RIESGO: MensajeMotivacional[] = [
  { tipo: "riesgo", mensaje: "Alerta: estás gastando más de lo que ingresas este mes", emoji: "🚨" },
  { tipo: "riesgo", mensaje: "¡Atención! Tu balance es negativo", emoji: "🚨" },
  { tipo: "riesgo", mensaje: "Urgente: reduce tus gastos inmediatamente", emoji: "⛔" },
  { tipo: "riesgo", mensaje: "Tu balance necesita atención urgente", emoji: "🔴" },
];

// Determinar el estado financiero basado en estadísticas
export function determinarEstadoFinanciero(
  totalIngresos: number,
  totalEgresos: number,
  balance: number
): EstadoFinanciero {
  if (balance < 0) {
    return "riesgo";
  }
  
  if (totalIngresos > 0) {
    const porcentajeGasto = (totalEgresos / totalIngresos) * 100;
    if (porcentajeGasto >= 70) {
      return "precaucion";
    }
  }
  
  return "saludable";
}

// Obtener un mensaje motivacional aleatorio según el estado
export function getMensajeMotivacional(estado: EstadoFinanciero): MensajeMotivacional {
  let mensajes: MensajeMotivacional[];
  
  switch (estado) {
    case "saludable":
      mensajes = MENSAJES_SALUDABLE;
      break;
    case "precaucion":
      mensajes = MENSAJES_PRECAUCION;
      break;
    case "riesgo":
      mensajes = MENSAJES_RIESGO;
      break;
  }
  
  const indiceAleatorio = Math.floor(Math.random() * mensajes.length);
  return mensajes[indiceAleatorio];
}

// Obtener emoji según el estado financiero
export function getEmojiEstado(estado: EstadoFinanciero): string {
  switch (estado) {
    case "saludable":
      return "😊";
    case "precaucion":
      return "😐";
    case "riesgo":
      return "😟";
  }
}
