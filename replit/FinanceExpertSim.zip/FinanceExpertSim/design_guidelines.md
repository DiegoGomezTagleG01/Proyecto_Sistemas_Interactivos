# Diseño del Simulador Interactivo de Finanzas Personales

## Enfoque de Diseño

**Sistema de Referencia**: Inspiración en aplicaciones financieras modernas como Mint, YNAB (You Need A Budget), y la claridad visual de aplicaciones de productividad como Notion. Énfasis en visualización de datos clara, retroalimentación inmediata y gamificación motivadora.

## Principios de Diseño Fundamentales

1. **Claridad Financiera**: Diferenciación inmediata entre ingresos (🟢 verde/azul) y egresos (🔴 rojo/naranja)
2. **Motivación Visual**: Uso estratégico de emojis, colores y mensajes para fomentar buenos hábitos
3. **Retroalimentación Inmediata**: Actualizaciones en tiempo real con animaciones suaves
4. **Accesibilidad Emocional**: Mensajes comprensibles y motivadores, nunca punitivos

## Estructura de Layout

### Ventana Principal (Single-Page Interface)
- **Header**: Barra superior con título del simulador, balance total prominente y botón de configuración (icono ⚙️)
- **Panel de Formulario**: Área dedicada para registro de transacciones (33% del ancho en desktop)
- **Panel de Visualización**: Gráficas y resumen financiero (67% del ancho en desktop)
- **Panel de Mensajes**: Zona de alertas y mensajes motivacionales flotantes (toasts)

### Panel de Configuración (Overlay/Modal)
- Modal centrado con fondo semi-transparente (backdrop blur)
- Pestañas o secciones para: Apariencia (modo oscuro/claro), Temas de color, Categorías personalizadas
- Botón de cerrar prominente

## Sistema de Espaciado

Utilizar unidades Tailwind: **4, 8, 12, 16, 24, 32** para mantener ritmo vertical consistente.

- Padding de secciones: `p-8` en mobile, `p-12` en desktop
- Gaps en grids: `gap-6` para tarjetas, `gap-4` para elementos de formulario
- Márgenes entre secciones principales: `mb-8` a `mb-12`

## Tipografía

### Fuentes
- **Principal**: 'Inter' o 'Poppins' vía Google Fonts para interfaz moderna y legible
- **Números/Montos**: 'JetBrains Mono' o 'Roboto Mono' para cifras financieras (claridad en dígitos)
- **Títulos**: Weight 700 (Bold) para headers
- **Cuerpo**: Weight 400 (Regular) para texto general
- **Énfasis**: Weight 600 (SemiBold) para montos y datos destacados

### Jerarquía
- **H1 (Título Principal)**: 2.5rem (40px) - Título del simulador
- **H2 (Secciones)**: 1.75rem (28px) - "Registrar Transacción", "Resumen Financiero"
- **H3 (Sub-secciones)**: 1.25rem (20px) - Categorías, títulos de gráficas
- **Body/Formularios**: 1rem (16px) - Texto base
- **Montos Grandes**: 3rem (48px) - Balance total
- **Labels**: 0.875rem (14px) - Etiquetas de formulario

## Sistema de Colores

### Colores Base (Variables CSS)
```
--color-ingreso: #10b981 (Verde esmeralda)
--color-egreso: #ef4444 (Rojo vibrante)
--color-alerta-precaucion: #f59e0b (Amarillo/Naranja)
--color-exito: #22c55e (Verde claro)
--color-fondo-principal: #ffffff (Claro) / #1f2937 (Oscuro)
--color-fondo-secundario: #f9fafb (Claro) / #111827 (Oscuro)
--color-texto-principal: #111827 (Claro) / #f9fafb (Oscuro)
```

### Aplicación de Colores
- **Ingresos**: Fondos sutiles verde claro con bordes verdes sólidos
- **Egresos**: Fondos sutiles rojo/naranja claro con bordes rojos/naranjas
- **Balance Positivo**: Texto y iconos verdes grandes
- **Balance Negativo**: Texto y iconos rojos grandes con animación de atención
- **Alertas**: Banners o toasts con colores de estado (🟢🟡🔴)

## Componentes Principales

### Formulario de Registro
- **Campos**: Tipo (Radio buttons: Ingreso/Egreso), Categoría (Select con emojis), Monto (Input numérico), Descripción (Textarea opcional), Fecha (Date picker)
- **Categorías Predefinidas**: 💰 Salario, 🍕 Comida, 🏠 Vivienda, 🚗 Transporte, 🎉 Entretenimiento, 🏥 Salud, 📚 Educación, 💳 Otros
- **Botón Submit**: Grande, colorido, con micro-animación al hover
- **Validación**: Mensajes inline debajo de campos con iconos ⚠️

### Tarjetas de Resumen
- **Balance Total**: Tarjeta prominente en la parte superior con monto grande, emoji de estado (😊/😐/😟) y mensaje breve
- **Ingresos Totales**: Tarjeta con fondo verde sutil, ícono 📈 y monto
- **Egresos Totales**: Tarjeta con fondo rojo sutil, ícono 📉 y monto
- **Diseño**: Bordes redondeados (rounded-xl), sombras suaves, padding generoso

### Visualización de Datos (Chart.js)
- **Gráfico de Líneas**: Evolución temporal del balance (últimos 30 días), área bajo la curva coloreada según estado
- **Gráfico de Dona**: Distribución de gastos por categoría, colores distintivos por categoría con leyenda
- **Animaciones**: Transiciones suaves al cargar y actualizar datos
- **Tooltips**: Informativos con detalles precisos al hover

### Sistema de Mensajes Motivacionales
- **Toast Notifications**: Aparición desde arriba o esquina superior derecha
- **Ejemplos de Mensajes**:
  - Balance positivo: "💪 ¡Excelente! Sigues en positivo, sigue así"
  - Precaución: "⚠️ Atención: tus gastos están alcanzando el 70% de tus ingresos"
  - Riesgo: "🚨 Alerta: estás gastando más de lo que ingresas este mes"
  - Logro: "🎉 ¡Felicidades! Alcanzaste 7 días con balance positivo - 💎 Ahorrista Nivel 1"
- **Duración**: 5-7 segundos con barra de progreso, opción de cerrar manualmente

### Gamificación
- **Barra de Progreso**: Para metas de ahorro, con porcentaje y emoji de recompensa
- **Insignias/Logros**: Visualización tipo badge con ícono, nombre y descripción breve
- **Niveles**: 
  - 💎 Ahorrista Nivel 1 (7 días positivo)
  - 🏆 Guardián del Ahorro (30 días positivo)
  - 👑 Maestro Financiero (Meta de ahorro alcanzada)

## Animaciones y Transiciones

### Animaciones Sutiles (CSS)
- **Entrada de elementos**: Fade-in + slide-up (300ms) para tarjetas y formularios
- **Actualización de datos**: Pulse suave (200ms) en números cuando cambian
- **Hover en botones**: Scale 1.05 + shadow-lg (150ms)
- **Toast messages**: Slide-in desde top (400ms cubic-bezier)

### Efectos Visuales Especiales
- **Confetti/Partículas**: Al alcanzar logros importantes (usar biblioteca ligera como canvas-confetti via CDN)
- **Shake animation**: Sutil en balance negativo para llamar atención

## Responsive Design

### Breakpoints
- **Mobile**: Stack vertical de todos los componentes, formulario arriba, gráficas abajo
- **Tablet (768px+)**: Layout de 2 columnas, formulario + resumen
- **Desktop (1024px+)**: Layout de 3 columnas o asimétrico (33% formulario, 67% visualización)

### Adaptaciones Móviles
- Gráficas: Altura reducida pero legibles
- Botones: Táctiles (min 44px altura)
- Formularios: Campos más espaciados verticalmente
- Modal de configuración: Full-screen en mobile

## Efectos Sonoros (Howler.js)

### Eventos con Sonido
- **Registro exitoso**: Sonido suave de "ding" o "success"
- **Logro desbloqueado**: Fanfarria breve
- **Alerta/Warning**: Tono de notificación discreta
- **Implementación**: Controles de volumen en configuración, opción de silenciar

## Accesibilidad

- Contraste mínimo WCAG AA (4.5:1 para texto normal)
- Labels visibles en todos los formularios
- Estados de foco claros con outline colorido
- Mensajes de error descriptivos
- Compatibilidad con lectores de pantalla (aria-labels)

## Imágenes

**No se requieren imágenes de hero** para esta aplicación. El enfoque es 100% en interfaz de datos funcional, gráficas y visualización de información financiera. Toda la comunicación visual se logra mediante:
- Emojis integrados en texto
- Iconos vectoriales (Font Awesome o Heroicons via CDN)
- Gráficas generadas por Chart.js
- Colores y tipografía expresiva